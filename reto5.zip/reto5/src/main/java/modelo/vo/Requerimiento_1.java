package modelo.vo;

public class Requerimiento_1 {
    
    // Atributes
    private Integer Nro_Lideres;
    private String Ciudad_Residencia;

    // Contructor
    public Requerimiento_1(){

    }

    public Integer getNro_Lideres() {
        return Nro_Lideres;
    }

    public void setNro_Lideres(Integer nro_Lideres) {
        Nro_Lideres = nro_Lideres;
    }

    public String getCiudad_Residencia() {
        return Ciudad_Residencia;
    }

    public void setCiudad_Residencia(String ciudad_Residencia) {
        Ciudad_Residencia = ciudad_Residencia;
    }
    
}
