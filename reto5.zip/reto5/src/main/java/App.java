import controlador.*;

public class App {
    public static void main( String[] args ){

        // Instanciar controlador e iniciarlo
        Controlador controlador = new Controlador();
        controlador.inicio();
    }
}
